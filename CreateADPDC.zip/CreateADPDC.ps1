﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

		[Parameter(Mandatory)]
        [String]$RootDN,
		
		[Parameter(Mandatory)]
        [String]$dName,

		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$UserPassword,

		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$ServicePassword,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface = Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

	    WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

        Script EnableDNSDiags
	    {
      	    SetScript = { 
		        Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false }
	        DependsOn = "[WindowsFeature]DNS"
        }

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
	    }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
	        DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec = $RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk DataDisk 
		{
            DiskNumber = 2
            DriveLetter = "F"
			FSLabel = 'Data'
			FSFormat = 'NTFS'
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
	        DependsOn="[WindowsFeature]DNS" 
        } 

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
         
        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "C:\Windows\NTDS"
            LogPath = "C:\Windows\NTDS"
            SysvolPath = "C:\Windows\SYSVOL"
        }
		
		xADOrganizationalUnit ServiceAccounts
		{
			Name = "Service Accounts"
			Path = $RootDN
			Description = "Organizational Unit for Service Accounts"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xADOrganizationalUnit THIncITUsers
		{
			Name = "THIncIT Users"
			Path = $RootDN
			Description = "Organizational Unit for THIncIT Users"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xADOrganizationalUnit FDXUsers
		{
			Name = "FDX Users"
			Path = $RootDN
			Description = "Organizational Unit for FDX Users"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xADUser SQLAdmin
		{
			DomainName = $DomainName
			UserName = "SQLAdmin"
			Password = $ServicePassword
			Ensure = "Present"
			UserPrincipalName = "SQLAdmin@"+$DomainName
			Path = "OU=Service Accounts, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}

		xADUser FAS_Service
		{
			DomainName = $DomainName
			UserName = "FAS_Service"
			Password = $ServicePassword
			Ensure = "Present"
			UserPrincipalName = "FAS_Service@"+$DomainName
			Path = "OU=Service Accounts, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}

		xADUser ProductTeamAdmin
		{
			DomainName = $DomainName
			UserName = "ProductTeamAdmin"
			Password = $ServicePassword
			Ensure = "Present"
			UserPrincipalName = "ProductTeamAdmin@"+$DomainName
			Path = "OU=Service Accounts, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}
		
		xADUser Ldap_bind_user
		{
			DomainName = $DomainName
			UserName = "Ldap_bind_user"
			Password = $ServicePassword
			Ensure = "Present"
			Path = "OU=Service Accounts, "+$RootDN
			UserPrincipalName = "Ldap_bind_user@"+$DomainName
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}
		
		xADUser VPNAdmin
		{
			DomainName = $DomainName
			UserName = "VPNAdmin"
			Password = $ServicePassword
			Ensure = "Present"
			UserPrincipalName = "VPNAdmin@"+$DomainName
			Path = "OU=Service Accounts, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}	

		xADUser DavidHaver
		{
			DomainName = $DomainName
			UserName = "David.Haver"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "David.Haver@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	
		
		xADUser ChrisMartin
		{
			DomainName = $DomainName
			UserName = "Chris.Martin"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Chris.Martin@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}
		
		xADUser AlexLetarte
		{
			DomainName = $DomainName
			UserName = "Alex.Letarte"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Alex.Letarte@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	

		xADUser StevenPinkos
		{
			DomainName = $DomainName
			UserName = "Steven.Pinkos"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Steven.Pinkos@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	

		xADUser XinWang
		{
			DomainName = $DomainName
			UserName = "Xin.Wang"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Xin.Wang@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	

		xADUser RogerJones
		{
			DomainName = $DomainName
			UserName = "Roger.Jones"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Roger.Jones@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	
	
		xADUser CharlesPhelps
		{
			DomainName = $DomainName
			UserName = "Charles.Phelps"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Charles.Phelps@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	

		xADUser DonDillon
		{
			DomainName = $DomainName
			UserName = "Don.Dillon"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Don.Dillon@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	

		xADUser Kevin.Williams
		{
			DomainName = $DomainName
			UserName = "Kevin.Williams"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Kevin.Williams@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	
		xADUser TestUser
		{
			DomainName = $DomainName
			UserName = "Test.User"
			Password = $UserPassword
			Ensure = "Present"
			UserPrincipalName = "Test.User@"+$DomainName
			Path = "OU=THIncIT Users, "+$RootDN
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	

		xADUser FasAdmin
		{
			DomainName = $DomainName
			UserName = "FASAdmin"
			Password = $Admincreds
			Ensure = "Present"
			UserPrincipalName = "FASAdmin@"+$DomainName
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]THIncITUsers"
		}	
	
		xADGroup VPNGroup
		{
			GroupName = "VPN Group"
			Path = "OU=Service Accounts, "+$RootDN
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}		
		
		Package ScreenConnect
		{
			Name      = "ScreenConnect Client (a99d1dcab9cd0ca0)"
			Path      = "C:\Program Files\WindowsPowerShell\Modules\xInstalls\techConnect\TechConnect.ClientSetup.msi"
			ProductId = "7C5A222F-09FB-4A01-949D-E16060271420"
		}


   }
} 