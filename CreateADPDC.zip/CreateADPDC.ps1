﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

		[Parameter(Mandatory)]
        [String]$RootDN,
		
		[Parameter(Mandatory)]
        [String]$dName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface = Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)
	
	$SQLAdmin = "SQLAdmin@"+$DomainName
	$FAS_Service = "FAS_Service@"+$DomainName
	$ProductTeamAdmin = "ProductTeamAdmin@"+$DomainName
	$Ldap_bind_user = "Ldap_bind_user@"+$DomainName
	$VPNAdmin = "VPNAdmin@"+$DomainName
	
	$SQLAdminCN = "CN=SQLAdmin, OU=Service Accounts, DC="+$dName+", DC=fascloud, DC=com"
	$FASServiceCN = "CN=FAS_Service, OU=Service Accounts, DC="+$dName+", DC=fascloud, DC=com"
	$ProductTeamAdminCN = "CN=ProductTeamAdmin, OU=Service Accounts, DC="+$dName+", DC=fascloud, DC=com"
	$Ldap_bind_userCN = "CN=Ldap_bind_user, OU=Service Accounts, DC="+$dName+", DC=fascloud, DC=com"
	$VPNAdminCN = "CN=VPNAdmin, OU=Service Accounts, DC="+$dName+", DC=fascloud, DC=com"
	
	$VPNGroupPath = "OU=Service Accounts, "+$RootDN

    Node localhost
    {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

	    WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

        Script EnableDNSDiags
	    {
      	    SetScript = { 
		        Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false }
	        DependsOn = "[WindowsFeature]DNS"
        }

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
	    }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
	        DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec = $RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk DataDisk 
		{
            DiskNumber = 2
            DriveLetter = "F"
			FSLabel = 'Data'
			FSFormat = 'NTFS'
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
	        DependsOn="[WindowsFeature]DNS" 
        } 

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
         
        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "C:\NTDS"
            LogPath = "C:\NTDS"
            SysvolPath = "C:\SYSVOL"
        }
		
		xADOrganizationalUnit ServiceAccounts
		{
			Name = "Service Accounts"
			Path = $RootDN
			Description = "Organizational Unit for Service Accounts"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xADOrganizationalUnit THIncITUsers
		{
			Name = "THIncIT Users"
			Path = $RootDN
			Description = "Organizational Unit for THIncIT Users"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xADOrganizationalUnit FDXUsers
		{
			Name = "FDX Users"
			Path = $RootDN
			Description = "Organizational Unit for FDX Users"
			Ensure = "Present"
			DependsOn = "[xADDomain]FirstDS"
		}

		xADUser SQLAdmin
		{
			DomainName = $DomainName
			UserName = "SQLAdmin"
			Password = $DomainCreds
			Ensure = "Present"
			CommonName = $SQLAdminCN
			UserPrincipalName = $SQLAdmin
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}

		xADUser FAS_Service
		{
			DomainName = $DomainName
			UserName = "FAS_Service"
			Password = $DomainCreds
			Ensure = "Present"
			CommonName = $FAS_ServiceCN
			UserPrincipalName = $FAS_Service
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}

		xADUser ProductTeamAdmin
		{
			DomainName = $DomainName
			UserName = "ProductTeamAdmin"
			Password = $DomainCreds
			Ensure = "Present"
			CommonName = $ProductTeamAdminCN
			UserPrincipalName = $ProductTeamAdmin
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}
		
		xADUser Ldap_bind_user
		{
			DomainName = $DomainName
			UserName = "Ldap_bind_user"
			Password = $DomainCreds
			Ensure = "Present"
			CommonName = $Ldap_bind_userCN
			UserPrincipalName = $Ldap_bind_user
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}
		
		xADUser VPNAdmin
		{
			DomainName = $DomainName
			UserName = "VPNAdmin"
			Password = $DomainCreds
			Ensure = "Present"
			CommonName = $VPNAdminCN
			UserPrincipalName = $VPNAdmin
			Enabled = $True
			PasswordNeverExpires = $True
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}	

		xADGroup VPNGroup
		{
			GroupName = "VPN Group"
			Path = $VPNGroupPath
			DependsOn = "[xADOrganizationalUnit]ServiceAccounts"
		}		
		

   }
} 